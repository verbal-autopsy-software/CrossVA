library(testthat)
library(CrossVA)

test_check("CrossVA")
